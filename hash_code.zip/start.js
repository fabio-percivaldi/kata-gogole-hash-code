/* eslint-disable camelcase */
'use strict'

const a_example = './tests/fixtures/input/a_example'

const { getDeliveryManager, createOutputFile } = require('./index')
const deliveryManager = getDeliveryManager(a_example)
const actualOrders = deliveryManager.getOrders()
createOutputFile(actualOrders, 'output-example')
