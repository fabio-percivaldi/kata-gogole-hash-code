'use strict'

const fs = require('fs')
const pickPizza = require('./pickPizza')

const deliverPizzaForTeam = (teamCount, availablePizzas) => {
  const order = []
  for (let j = 0; j < teamCount; j++) {
    const orderIngrMap = {}

    if (availablePizzas.length > 0 && availablePizzas.length >= (2 - order.length)) {
      const pizza = pickPizza(orderIngrMap, availablePizzas)
      pizza.ingredients.forEach(ingr => {
        orderIngrMap[ingr] = true
      })
      order.push(pizza)
    }
  }
  return order
}

const getDeliveryManager = (path) => {
  const file = fs.readFileSync(path)
  const stringifiedFile = file.toString()
  const lines = stringifiedFile.split('\n')
  const deliveryManager = lines.reduce((acc, curr, index) => {
    const data = {}
    const pizzas = []
    const lineValues = curr.split(' ')

    if (curr.trim() === '') {
      return acc
    }
    if (index === 0) {
      const [pizzaCount, twoTeamCount, threeTeamCount, fourTeamCount] = lineValues
      data.pizzaCount = parseInt(pizzaCount)
      data.twoTeamCount = parseInt(twoTeamCount)
      data.threeTeamCount = parseInt(threeTeamCount)
      data.fourTeamCount = parseInt(fourTeamCount)
    } else {
      const pizza = {
        id: index - 1,
        ingredients: [],
      }
      const [ingredientsCountString] = lineValues
      pizza.ingredientsCount = parseInt(ingredientsCountString)
      for (let i = 1; i <= pizza.ingredientsCount; i += 1) {
        pizza.ingredients.push(lineValues[i])
      }
      pizzas.push(pizza)
      acc.pizzas = acc.pizzas.concat(pizzas)
    }

    return {
      ...acc,
      ...data,
    }
  }, {
    pizzas: [],
  })
  return {
    ...deliveryManager,
    getOrders: () => {
      // Ordino le pizze per numero di ingredienti desc (questo in lettuta del file ed una volta sola)
      const orders = []
      const { twoTeamCount, threeTeamCount, fourTeamCount, pizzas } = deliveryManager
      let availablePizzas = JSON.parse(JSON.stringify(pizzas))

      availablePizzas = availablePizzas.sort((pa, pb) => {
        return pa.ingredientsCount < pb.ingredientsCount
      })

      for (let i = 0; i < twoTeamCount; i++) {
        const order = {
          pizzas: deliverPizzaForTeam(2, availablePizzas),
          teamMembersCount: 2,
        }
        orders.push(order)
      }
      for (let i = 0; i < threeTeamCount; i++) {
        const order = {
          pizzas: deliverPizzaForTeam(3, availablePizzas),
          teamMembersCount: 3,
        }
        orders.push(order)
      }
      for (let i = 0; i < fourTeamCount; i++) {
        const order = {
          pizzas: deliverPizzaForTeam(4, availablePizzas),
          teamMembersCount: 4,
        }
        orders.push(order)
      }

      return orders.filter(order => order.pizzas.length > 0)
    },
  }
}


const createOutputFile = (orders, fileName) => {
  const teamServedCount = orders.length
  const fileOutputContent = orders.reduce((acc, order) => {
    const { teamMembersCount, pizzas } = order
    const pizzaIds = pizzas.map(pizza => pizza.id).join(' ')
    return `${acc}\n${teamMembersCount} ${pizzaIds}`
  }, `${teamServedCount}`)

  fs.writeFileSync(fileName || 'subFile.out', fileOutputContent)
}

module.exports = { getDeliveryManager, createOutputFile }
